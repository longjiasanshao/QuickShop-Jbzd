package com.ghostchu.quickshop.compatibility.worldguard;

import com.ghostchu.quickshop.QuickShop;
import com.ghostchu.quickshop.api.event.economy.ShopPurchaseEvent;
import com.ghostchu.quickshop.api.event.management.ShopCreateEvent;
import com.ghostchu.quickshop.api.event.management.ShopPermissionCheckEvent;
import com.ghostchu.quickshop.api.shop.Shop;
import com.ghostchu.quickshop.api.shop.permission.BuiltInShopPermission;
import com.ghostchu.quickshop.compatibility.CompatibilityModule;
import com.ghostchu.quickshop.shop.SimpleShopChunk;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.registry.FlagConflictException;
import com.sk89q.worldguard.protection.flags.registry.FlagRegistry;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

public final class Main extends CompatibilityModule implements Listener {

  private StateFlag createFlag;
  private StateFlag tradeFlag;
  private int limitPerRegion;

  @Override
  public void onLoad() {

    saveDefaultConfig();
    final FlagRegistry registry = WorldGuard.getInstance().getFlagRegistry();
    try {
      // create a flag with the name "my-custom-flag", defaulting to true
      final StateFlag createFlag = new StateFlag("quickshophikari-create", getConfig().getBoolean("create.default-allow", false));
      final StateFlag tradeFlag = new StateFlag("quickshophikari-trade", getConfig().getBoolean("trade.default-allow", true));
      registry.register(createFlag);
      registry.register(tradeFlag);
      this.createFlag = createFlag;
      this.tradeFlag = tradeFlag;
    } catch(final FlagConflictException e) {
      // some other plugin registered a flag by the same name already.
      // you can use the existing flag, but this may cause conflicts - be sure to check type
      Flag<?> existing = registry.get("quickshophikari-create");
      if(existing instanceof final StateFlag createFlag) {
        this.createFlag = createFlag;
      } else {
        getLogger().log(Level.WARNING, "Could not register 'quickshophikari-create' flag! CONFLICT!", e);
        Bukkit.getPluginManager().disablePlugin(this);
        return;
      }
      existing = registry.get("quickshophikari-trade");
      if(existing instanceof final StateFlag tradeFlag) {
        this.tradeFlag = tradeFlag;
      } else {
        getLogger().log(Level.WARNING, "Could not register 'quickshophikari-trade' flag! CONFLICT!", e);
        Bukkit.getPluginManager().disablePlugin(this);
        return;
      }
    }
    this.limitPerRegion = getConfig().getInt("max-shops-in-region");
    super.onLoad();
  }

  @Override
  public void init() {
    // There no init stuffs need to do
  }

  @EventHandler(ignoreCancelled = true)
  public void onPermissionCheck(final ShopPermissionCheckEvent event) {

    if(event.shop().isEmpty()) return;

    final Location shopLoc = event.shop().get().getLocation();
    final World world = shopLoc.getWorld();
    if(world == null) return;

    final RegionContainer container = WorldGuard.getInstance().getPlatform().getRegionContainer();
    final RegionManager manager = container.get(BukkitAdapter.adapt(world));
    if(manager == null) return;

    final ApplicableRegionSet set = manager.getApplicableRegions(BlockVector3.at(shopLoc.getX(), shopLoc.getY(), shopLoc.getZ()));

    // If outside regions - use default QuickShop permissions
    if(set.size() == 0) return;

    // Region owners can delete any shop within their own region
    for(final ProtectedRegion region : set.getRegions()) {
      if(region.getOwners().contains(event.playerUUID())) {
        if(event.pluginNamespace().equals(QuickShop.getInstance().getJavaPlugin().getName()) && event.permissionNode().equals(BuiltInShopPermission.DELETE.getRawNode())) {
          event.hasPermission(true);
        }
      }
    }
  }

  @EventHandler(ignoreCancelled = true)
  public void onShopCreate(final ShopCreateEvent event) {

    if(!event.phase().cancellable() || event.shop().isEmpty()) return;

    event.user().getBukkitPlayer().ifPresent(player->{
      final RegionContainer container = WorldGuard.getInstance().getPlatform().getRegionContainer();

      final RegionQuery query = container.createQuery();
      final Location shopLocation = event.shop().get().getLocation();
      final ApplicableRegionSet regions = query.getApplicableRegions(BukkitAdapter.adapt(shopLocation));

      final RegionManager manager = container.get(BukkitAdapter.adapt(shopLocation.getWorld()));

      if(manager != null && regions.size() == 0) {
        //we are in the global region.
        final ProtectedRegion globalRegion = manager.getRegion(ProtectedRegion.GLOBAL_REGION);
        if(globalRegion == null) return;

        final StateFlag.State createState = globalRegion.getFlag(this.createFlag);
        boolean createAllowed = getConfig().getBoolean("create.default-allow", false);
        if(createState != null) {
          createAllowed = createState == StateFlag.State.ALLOW;
        }

        if(!createAllowed) {
          event.setCancelled(true, getApi().getTextManager().of(event.user(), "addon.worldguard.creation-flag-test-failed").forLocale());
          return;
        }
        return;
      }

      if(!hasRegionAccess(player.getUniqueId(), regions)) {
        final LocalPlayer localPlayer = WorldGuardPlugin.inst().wrapPlayer(player);
        if(!query.testState(BukkitAdapter.adapt(shopLocation), localPlayer, this.createFlag)) {
          event.setCancelled(true, getApi().getTextManager().of(event.user(), "addon.worldguard.creation-flag-test-failed").forLocale());
          return;
        }
      }

      final Set<ProtectedRegion> regionSet = regions.getRegions();
      final List<Shop> shops = new ArrayList<>();
      regionSet.forEach(r->shops.addAll(getRegionShops(r, shopLocation.getWorld()).values()));

      if(limitPerRegion >= 0 && shops.size() + 1 > limitPerRegion) {
        event.setCancelled(true, getApi().getTextManager().of(event.user(), "addon.worldguard.reached-per-region-amount-limit").forLocale());
      }
    });
  }

  private Map<Location, Shop> getRegionShops(final ProtectedRegion region, final World world) {

    final Map<Location, Shop> shopMap = new HashMap<>();
    if(world == null) return shopMap;

    final BlockVector3 minPoint = region.getMinimumPoint();
    final BlockVector3 maxPoint = region.getMaximumPoint();

    for(int x = minPoint.x(); x <= maxPoint.x() + 16; x += 16) {
      for(int z = minPoint.z(); z <= maxPoint.z() + 16; z += 16) {
        final Location location = new Location(world, x, 0, z);
        final Map<Location, Shop> shopsInChunk = getApi().getShopManager().getShops(SimpleShopChunk.fromLocation(location));
        if(shopsInChunk != null) shopMap.putAll(shopsInChunk);
      }
    }
    return shopMap;
  }

  private boolean hasRegionAccess(final UUID playerId, final ApplicableRegionSet regions) {

    return regions.getRegions().stream().anyMatch(region->region.getOwners().contains(playerId) || region.getMembers().contains(playerId));
  }

  @EventHandler(ignoreCancelled = true)
  public void onShopPurchase(final ShopPurchaseEvent event) {

    event.getPurchaser().getBukkitPlayer().ifPresent(player->{
      final RegionContainer container = WorldGuard.getInstance().getPlatform().getRegionContainer();
      final RegionQuery query = container.createQuery();
      final Location shopLocation = event.getShop().getLocation();
      final ApplicableRegionSet regions = query.getApplicableRegions(BukkitAdapter.adapt(shopLocation));

      final RegionManager manager = container.get(BukkitAdapter.adapt(shopLocation.getWorld()));

      if(manager != null && regions.size() == 0) {
        //we are in the global region.
        final ProtectedRegion globalRegion = manager.getRegion(ProtectedRegion.GLOBAL_REGION);
        if(globalRegion == null) return;

        final StateFlag.State tradeState = globalRegion.getFlag(this.tradeFlag);
        boolean tradeAllowed = getConfig().getBoolean("trade.default-allow", true);
        if(tradeState != null) {
          tradeAllowed = tradeState == StateFlag.State.ALLOW;
        }

        if(!tradeAllowed) {
          event.setCancelled(true, getApi().getTextManager().of(event.getPurchaser(), "addon.worldguard.trade-flag-test-failed").forLocale());
          return;
        }
        return;
      }

      if(!hasRegionAccess(player.getUniqueId(), regions)) {
        final LocalPlayer localPlayer = WorldGuardPlugin.inst().wrapPlayer(player);
        if(!query.testState(BukkitAdapter.adapt(shopLocation), localPlayer, this.tradeFlag)) {
          event.setCancelled(true, getApi().getTextManager().of(event.getPurchaser(), "addon.worldguard.trade-flag-test-failed").forLocale());
        }
      }
    });
  }
}
