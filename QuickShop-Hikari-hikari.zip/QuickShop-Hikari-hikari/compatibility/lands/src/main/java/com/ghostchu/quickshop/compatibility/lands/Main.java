package com.ghostchu.quickshop.compatibility.lands;

import com.ghostchu.quickshop.QuickShop;
import com.ghostchu.quickshop.api.event.economy.ShopPurchaseEvent;
import com.ghostchu.quickshop.api.event.management.ShopCreateEvent;
import com.ghostchu.quickshop.api.event.management.ShopPermissionCheckEvent;
import com.ghostchu.quickshop.api.shop.Shop;
import com.ghostchu.quickshop.api.shop.ShopChunk;
import com.ghostchu.quickshop.api.shop.permission.BuiltInShopPermission;
import com.ghostchu.quickshop.common.util.CommonUtil;
import com.ghostchu.quickshop.compatibility.CompatibilityModule;
import com.ghostchu.quickshop.obj.QUserImpl;
import com.ghostchu.quickshop.util.Util;
import me.angeschossen.lands.api.LandsIntegration;
import me.angeschossen.lands.api.events.LandDeleteEvent;
import me.angeschossen.lands.api.events.LandUntrustPlayerEvent;
import me.angeschossen.lands.api.events.PlayerLeaveLandEvent;
import me.angeschossen.lands.api.land.Land;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;

import java.util.Map;
import java.util.UUID;

public final class Main extends CompatibilityModule {

  private boolean ignoreDisabledWorlds;
  private boolean whitelist;
  private LandsIntegration landsIntegration;
  private boolean deleteWhenLosePermission;
  private boolean deleteWhenLandDeleted;
  private boolean allowMemberDeletion;

  @Override
  public void init() {

    landsIntegration = LandsIntegration.of(this);
    ignoreDisabledWorlds = getConfig().getBoolean("ignore-disabled-worlds");
    whitelist = getConfig().getBoolean("whitelist-mode");
    deleteWhenLosePermission = getConfig().getBoolean("delete-on-lose-permission");
    deleteWhenLandDeleted = getConfig().getBoolean("delete-shops-in-land-when-land-deleted");
    allowMemberDeletion = getConfig().getBoolean("allow-member-deletion");
  }

  @EventHandler(ignoreCancelled = true)
  public void onPreCreation(final ShopCreateEvent event) {

    final Location loc = event.location();
    if(!event.phase().cancellable() || loc.getWorld() == null) {

      return;
    }

    if(landsIntegration.getWorld(loc.getWorld()) == null) {
      if(!ignoreDisabledWorlds) {
        event.setCancelled(true, getApi().getTextManager().of(event.user(), "addon.lands.world-not-enabled").forLocale());
        return;
      }
    }

    final Chunk locChunk = loc.getChunk();
    final Land land = landsIntegration.getLandByChunk(loc.getWorld(), locChunk.getX(), locChunk.getZ());
    final UUID id = event.user().getUniqueId();
    if(land != null && id != null) {
      if(land.getOwnerUID().equals(event.user().getUniqueId()) || land.isTrusted(id)) {
        return;
      }
      event.setCancelled(true, getApi().getTextManager().of(event.user(), "addon.lands.creation-denied").forLocale());
    } else {
      if(whitelist) {
        event.setCancelled(true, getApi().getTextManager().of(event.user(), "addon.lands.creation-denied").forLocale());
      }
    }
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onLandsMember(final PlayerLeaveLandEvent event) {

    if(!deleteWhenLosePermission || event.getLandPlayer() == null) {
      return;
    }
    deleteShopInLand(event.getLand(), event.getLandPlayer().getUUID());
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onLandsDeleted(final LandDeleteEvent event) {

    if(!deleteWhenLandDeleted || event.getLandPlayer() == null) {
      return;
    }
    deleteShopInLand(event.getLand(), event.getLandPlayer().getUUID());
  }

  private void deleteShopInLand(final Land land, final UUID target) {
    //Getting all shop with world-chunk-shop mapping
    for(final Map.Entry<String, Map<ShopChunk, Map<Location, Shop>>> entry : getApi().getShopManager().getShops().entrySet()) {
      //Matching world
      final World world = getServer().getWorld(entry.getKey());
      if(world != null) {
        //Matching chunk
        for(final Map.Entry<ShopChunk, Map<Location, Shop>> chunkedShopEntry : entry.getValue().entrySet()) {
          final ShopChunk shopChunk = chunkedShopEntry.getKey();
          if(land.hasChunk(world, shopChunk.getX(), shopChunk.getZ())) {
            //Matching Owner and delete it
            final Map<Location, Shop> shops = chunkedShopEntry.getValue();
            for(final Shop shop : shops.values()) {
              final UUID owner = shop.getOwner().getUniqueIdIfRealPlayer().orElse(null);
              if(owner == null) {
                continue;
              }
              if(target.equals(owner)) {
                recordDeletion(QUserImpl.createFullFilled(CommonUtil.getNilUniqueId(), "Lands", false), shop, "Lands: shop deleted because owner lost permission");
                // Use regionThread for Folia/Canvas compatibility - must run on the region thread for this location
                Util.regionThread(shop.getLocation(), ()->getApi().getShopManager().deleteShop(shop));
              }
            }
          }
        }
      }
    }
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onLandsPermissionChanges(final LandUntrustPlayerEvent event) {

    if(!deleteWhenLosePermission) {
      return;
    }
    deleteShopInLand(event.getLand(), event.getTargetUUID());
  }

  @EventHandler(ignoreCancelled = true)
  public void onTrading(final ShopPurchaseEvent event) {

    if(event.getShop().getLocation().getWorld() == null
       || landsIntegration.getWorld(event.getShop().getLocation().getWorld()) == null) {
      if(ignoreDisabledWorlds) {
        return;
      }
      event.setCancelled(true, getApi().getTextManager().of(event.getPurchaser(), "addon.lands.world-not-enabled").forLocale());
    }
  }

  @EventHandler(ignoreCancelled = true)
  public void permissionOverride(final ShopPermissionCheckEvent event) {

    if(event.shop().isEmpty()) {
      return;
    }

    final Location shopLoc = event.shop().get().getLocation();
    if(shopLoc.getWorld() == null) {
      return;
    }

    final Chunk locChunk = shopLoc.getChunk();
    final Land land = landsIntegration.getLandByChunk(shopLoc.getWorld(), locChunk.getX(), locChunk.getZ());
    if(land == null) {
      return;
    }

    // Check if this is a delete permission check from QuickShop
    if(!event.pluginNamespace().equals(QuickShop.getInstance().getJavaPlugin().getName()) 
       || !event.permissionNode().equals(BuiltInShopPermission.DELETE.getRawNode())) {
      return;
    }

    // Land owner can always delete shops in their land
    if(land.getOwnerUID().equals(event.playerUUID())) {
      event.hasPermission(true);
      return;
    }

    // If allowMemberDeletion is enabled, trusted members can also delete shops in the land
    if(allowMemberDeletion && land.isTrusted(event.playerUUID())) {
      event.hasPermission(true);
    }
  }
}
