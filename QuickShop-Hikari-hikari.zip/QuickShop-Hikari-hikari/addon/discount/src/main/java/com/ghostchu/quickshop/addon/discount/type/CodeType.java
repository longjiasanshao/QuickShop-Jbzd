package com.ghostchu.quickshop.addon.discount.type;

public enum CodeType {
  SERVER_ALL_SHOPS,
  PLAYER_ALL_SHOPS,
  SPECIFIC_SHOPS
}
