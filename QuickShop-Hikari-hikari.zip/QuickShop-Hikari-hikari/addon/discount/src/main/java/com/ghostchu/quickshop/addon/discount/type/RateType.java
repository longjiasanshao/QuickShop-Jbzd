package com.ghostchu.quickshop.addon.discount.type;

public enum RateType {
  FIXED,
  PERCENTAGE
}
