package com.ghostchu.quickshop.addon.reremakemigrator.migratecomponent;

import com.ghostchu.quickshop.QuickShop;
import com.ghostchu.quickshop.addon.reremakemigrator.Main;
import com.ghostchu.quickshop.api.shop.permission.BuiltInShopPermissionGroup;
import com.ghostchu.quickshop.common.util.CommonUtil;
import com.ghostchu.quickshop.common.util.QuickExecutor;
import com.ghostchu.quickshop.economy.QSBenefitProvider;
import com.ghostchu.quickshop.obj.QUserImpl;
import com.ghostchu.quickshop.shop.ContainerShop;
import com.ghostchu.quickshop.shop.inventory.BukkitInventoryWrapperManager;
import com.ghostchu.quickshop.util.ProgressMonitor;
import com.ghostchu.quickshop.util.performance.BatchBukkitExecutor;
import com.google.common.io.Files;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.BlockState;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.InventoryHolder;
import org.maxgamer.quickshop.api.shop.Shop;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class ShopMigrate extends AbstractMigrateComponent {

  private final boolean override;

  public ShopMigrate(final Main main, final QuickShop hikari, final org.maxgamer.quickshop.QuickShop reremake, final CommandSender sender, final boolean overrideExists) {

    super(main, hikari, reremake, sender);
    this.override = overrideExists;
  }

  @Override
  public boolean migrate() {

    final AtomicBoolean success = new AtomicBoolean(true);
    final AtomicInteger c = new AtomicInteger(0);
    final List<Shop> allShops = getReremake().getShopManager().getAllShops();
    final List<ContainerShop> preparedShops = new ArrayList<>();
    text("modules.shop.start-migrate", allShops.size()).send();
    final BatchBukkitExecutor<Shop> batchBukkitExecutor = new BatchBukkitExecutor<>();
    batchBukkitExecutor.addTasks(allShops);
    batchBukkitExecutor.startHandle(getHikari().getJavaPlugin(), reremakeShop->{
      text("modules.shop.migrate-entry", reremakeShop.toString(), c.incrementAndGet(), allShops.size()).send();
      try {
        final Location shopLoc = reremakeShop.getLocation();
        final com.ghostchu.quickshop.api.shop.Shop hikariShop = getHikari().getShopManager().getShop(shopLoc, true);
        if(hikariShop != null) {
          if(!override) {
            text("modules.shop.conflict", "SKIPPING").send();
            return;
          } else {
            text("modules.shop.conflict", "OVERWRITING").send();
            getHikari().getShopManager().deleteShop(hikariShop);
          }
        }
        final BlockState block = shopLoc.getBlock().getState();
        if(!(block instanceof final InventoryHolder container)) {
          getHikari().logger().warn("Shop Invalid: Shop block not a valid Container, failed to create InventoryHolder.");
          return;
        }
        final ContainerShop hikariRawShop = new ContainerShop(
                getHikari(),
                -1,
                shopLoc,
                Math.min(reremakeShop.getPrice(), 999999999999999999999999999.99), // DECIMAL (32,2) MAX
                reremakeShop.getItem().clone(),
                QUserImpl.createSync(getHikari().getPlayerFinder(), reremakeShop.getOwner()),
                reremakeShop.isUnlimited(),
                QuickShop.getInstance().getShopManager().shopTypeOrDefault(reremakeShop.getShopType().toID()),
                getReremakeShopExtra(reremakeShop),
                reremakeShop.getCurrency(),
                reremakeShop.isDisableDisplay(),
                reremakeShop.getTaxAccountActual() == null? null : QUserImpl.createSync(getHikari().getPlayerFinder(), reremakeShop.getTaxAccountActual()),
                getHikari().getJavaPlugin().getName(),
                ((BukkitInventoryWrapperManager)getHikari().getInventoryWrapperManager()).mklink(reremakeShop.getLocation()),
                null,
                Collections.emptyMap(),
                new QSBenefitProvider()
        );
        migrateReremakeBanAddonData(reremakeShop, hikariRawShop);
        hikariRawShop.setDirty();
        preparedShops.add(hikariRawShop);
      } catch(final Exception e) {
        getHikari().logger().warn("Failed to migrate shop " + reremakeShop, e);
      }
    }).thenAcceptAsync(a->{
      unloadAndMoveAwayReremake();
      registerHikariShops(preparedShops);
      saveHikariShops();
    }, QuickExecutor.getCommonExecutor()).exceptionally((error)->{
      getHikari().logger().warn("Error while migrating shops", error);
      success.set(false);
      return null;
    }).join();
    return success.get();
  }

  private void migrateReremakeBanAddonData(final Shop reremakeShop, final ContainerShop hikariRawShop) {

    try {
      final ConfigurationSection reremakeBanExtra = reremakeShop.getExtra(new MockPlugin("QuickShopBan"));
      for(final String bannedPlayer : reremakeBanExtra.getStringList("bannedplayers")) {
        if(!CommonUtil.isUUID(bannedPlayer)) continue;
        getHikari().logger().info("Migrating shop ban record {} at {} to new Hikari container shop.", bannedPlayer, reremakeShop);
        final UUID uuid = UUID.fromString(bannedPlayer);
        hikariRawShop.setPlayerGroup(uuid, BuiltInShopPermissionGroup.BLOCKED);
      }
    } catch(final Throwable th) {
      getHikari().logger().warn("Failed to migrate the shop ban record", th);
    }
  }

  private YamlConfiguration getReremakeShopExtra(final Shop reremakeShop) {

    final YamlConfiguration configuration = new YamlConfiguration();
    try {
      configuration.loadFromString(reremakeShop.saveExtraToYaml());
    } catch(final InvalidConfigurationException ignored) {
    }
    return configuration;
  }

  private void saveHikariShops() {

    final CompletableFuture<?>[] shopsToSaveFuture = getHikari().getShopManager().getAllShops().stream().filter(com.ghostchu.quickshop.api.shop.Shop::isDirty)
            .map(com.ghostchu.quickshop.api.shop.Shop::update)
            .toArray(CompletableFuture[]::new);
    text("modules.shop.saving-shops", shopsToSaveFuture.length).send();
    for(final CompletableFuture<?> completableFuture : new ProgressMonitor<>(shopsToSaveFuture, triple->text("modules.shop.save-entry", triple.getLeft(), triple.getMiddle()).send())) {
      try {
        completableFuture.join();
      } catch(final Exception e) {
        getHikari().logger().warn("Error while saving shops, skipping", e);
      }
    }
  }

  private void registerHikariShops(final List<ContainerShop> preparedShops) {

    for(final com.ghostchu.quickshop.api.shop.Shop shop : new ProgressMonitor<>(preparedShops, triple->text("modules.shop.register-entry", triple.getRight(), triple.getLeft(), triple.getMiddle()).send())) {
      getHikari().getShopManager().registerShop(shop, true).join();
      shop.setDirty();
    }
  }

  private void unloadAndMoveAwayReremake() {

    text("modules.shop.unloading-reremake").send();
    Bukkit.getPluginManager().disablePlugin(getReremake());
    final File reremakeDataDirectory = new File(getHikari().getDataFolder(), "QuickShop");
    try {
      Files.move(reremakeDataDirectory, new File(getHikari().getDataFolder(), "QuickShop.migrated"));
    } catch(final IOException e) {
      getHikari().logger().warn("Failed to move QuickShop-Reremake data directory, it may cause issues. You should manually move it to another location.");
    }
  }
}
