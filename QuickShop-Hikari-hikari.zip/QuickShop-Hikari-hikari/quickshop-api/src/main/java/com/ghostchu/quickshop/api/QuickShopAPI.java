package com.ghostchu.quickshop.api;

import com.ghostchu.quickshop.api.command.CommandManager;
import com.ghostchu.quickshop.api.database.DatabaseHelper;
import com.ghostchu.quickshop.api.economy.EconomyManager;
import com.ghostchu.quickshop.api.hook.Hook;
import com.ghostchu.quickshop.api.inventory.InventoryWrapperRegistry;
import com.ghostchu.quickshop.api.localization.text.TextManager;
import com.ghostchu.quickshop.api.registry.RegistryManager;
import com.ghostchu.quickshop.api.shop.ItemMatcher;
import com.ghostchu.quickshop.api.shop.PlayerFinder;
import com.ghostchu.quickshop.api.shop.ShopControlPanelManager;
import com.ghostchu.quickshop.api.shop.ShopItemBlackList;
import com.ghostchu.quickshop.api.shop.ShopManager;
import com.ghostchu.quickshop.api.shop.interaction.InteractionManager;
import com.vdurmont.semver4j.Semver;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import java.util.Map;

/**
 * The unique entry point to allow you to access most features of QuickShop
 */
public interface QuickShopAPI {
  
  // Static cache holder for QuickShop instance
  class InstanceCache {
    private static QuickShopAPI instance = null;
    
    private static void setInstance(QuickShopAPI inst) {
      instance = inst;
    }
    
    private static QuickShopAPI getInstance() {
      return instance;
    }
  }
  
  // Method for QuickShop to register itself
  static void registerInstance(QuickShopAPI instance) {
    InstanceCache.setInstance(instance);
  }

  static QuickShopAPI getInstance() {
    // First check the static cache
    QuickShopAPI cachedInstance = InstanceCache.getInstance();
    if(cachedInstance != null) {
      return cachedInstance;
    }
    
    // Try multiple approaches to get the QuickShop instance
    
    // Approach 1: Try to get from the static instance field directly
    try {
      final Class<?> quickShopClass = Class.forName("com.ghostchu.quickshop.QuickShop");
      final java.lang.reflect.Field instanceField = quickShopClass.getDeclaredField("instance");
      instanceField.setAccessible(true);
      final Object quickShopInstance = instanceField.get(null);
      if(quickShopInstance != null) {
        QuickShopAPI apiInstance = (QuickShopAPI) quickShopInstance;
        InstanceCache.setInstance(apiInstance); // Cache the instance
        return apiInstance;
      }
    } catch(final Exception e) {
      // Field access failed, continue to next approach
    }
    
    // Approach 2: Try to call the getInstance() method
    try {
      final Class<?> quickShopClass = Class.forName("com.ghostchu.quickshop.QuickShop");
      final java.lang.reflect.Method getInstanceMethod = quickShopClass.getDeclaredMethod("getInstance");
      final Object quickShopInstance = getInstanceMethod.invoke(null);
      if(quickShopInstance != null) {
        QuickShopAPI apiInstance = (QuickShopAPI) quickShopInstance;
        InstanceCache.setInstance(apiInstance); // Cache the instance
        return apiInstance;
      }
    } catch(final Exception e) {
      // Method access failed, continue to next approach
    }
    
    // Approach 3: Try to get from QuickShopBukkit plugin instance
    try {
      final org.bukkit.plugin.Plugin plugin = org.bukkit.Bukkit.getPluginManager().getPlugin("QuickShop-Hikari");
      if(plugin != null) {
        // Try to get QuickShop instance from QuickShopBukkit
        try {
          final java.lang.reflect.Method getQuickShopMethod = plugin.getClass().getDeclaredMethod("getQuickShop");
          final Object quickShopInstance = getQuickShopMethod.invoke(plugin);
          if(quickShopInstance != null && quickShopInstance instanceof QuickShopAPI) {
            QuickShopAPI apiInstance = (QuickShopAPI) quickShopInstance;
            InstanceCache.setInstance(apiInstance); // Cache the instance
            return apiInstance;
          }
        } catch(final Exception ex) {
          // Method access failed, try field access
          try {
            final java.lang.reflect.Field quickShopField = plugin.getClass().getDeclaredField("quickShop");
            quickShopField.setAccessible(true);
            final Object quickShopInstance = quickShopField.get(plugin);
            if(quickShopInstance != null && quickShopInstance instanceof QuickShopAPI) {
              QuickShopAPI apiInstance = (QuickShopAPI) quickShopInstance;
              InstanceCache.setInstance(apiInstance); // Cache the instance
              return apiInstance;
            }
          } catch(final Exception ex2) {
            // Field access failed
          }
        }
        // If plugin itself is QuickShopAPI, return it
        if(plugin instanceof QuickShopAPI) {
          QuickShopAPI apiInstance = (QuickShopAPI) plugin;
          InstanceCache.setInstance(apiInstance); // Cache the instance
          return apiInstance;
        }
      }
      // Also try "QuickShop" as plugin name
      final org.bukkit.plugin.Plugin plugin2 = org.bukkit.Bukkit.getPluginManager().getPlugin("QuickShop");
      if(plugin2 != null) {
        // Try to get QuickShop instance from QuickShopBukkit
        try {
          final java.lang.reflect.Method getQuickShopMethod = plugin2.getClass().getDeclaredMethod("getQuickShop");
          final Object quickShopInstance = getQuickShopMethod.invoke(plugin2);
          if(quickShopInstance != null && quickShopInstance instanceof QuickShopAPI) {
            QuickShopAPI apiInstance = (QuickShopAPI) quickShopInstance;
            InstanceCache.setInstance(apiInstance); // Cache the instance
            return apiInstance;
          }
        } catch(final Exception ex) {
          // Method access failed, try field access
          try {
            final java.lang.reflect.Field quickShopField = plugin2.getClass().getDeclaredField("quickShop");
            quickShopField.setAccessible(true);
            final Object quickShopInstance = quickShopField.get(plugin2);
            if(quickShopInstance != null && quickShopInstance instanceof QuickShopAPI) {
              QuickShopAPI apiInstance = (QuickShopAPI) quickShopInstance;
              InstanceCache.setInstance(apiInstance); // Cache the instance
              return apiInstance;
            }
          } catch(final Exception ex2) {
            // Field access failed
          }
        }
        // If plugin itself is QuickShopAPI, return it
        if(plugin2 instanceof QuickShopAPI) {
          QuickShopAPI apiInstance = (QuickShopAPI) plugin2;
          InstanceCache.setInstance(apiInstance); // Cache the instance
          return apiInstance;
        }
      }
    } catch(final Exception e) {
      // Plugin manager approach failed, continue to next approach
    }
    
    // Approach 4: Fall back to service provider
    try {
      final RegisteredServiceProvider<QuickShopProvider> provider = Bukkit.getServicesManager().getRegistration(QuickShopProvider.class);
      if(provider != null) {
        QuickShopProvider quickShopProvider = provider.getProvider();
        if(quickShopProvider != null) {
          QuickShopAPI apiInstance = quickShopProvider.getApiInstance();
          if(apiInstance != null) {
            InstanceCache.setInstance(apiInstance); // Cache the instance
            return apiInstance;
          }
        }
      }
    } catch(final Exception e) {
      // Service provider failed
    }
    
    // If we reach here, no instance available
    throw new IllegalStateException("QuickShop hadn't loaded at this moment.");
  }

  static Plugin getPluginInstance() {
    // Try multiple approaches to get the plugin instance
    
    // Approach 1: Try to get from Bukkit plugin manager directly
    try {
      final Plugin plugin = Bukkit.getPluginManager().getPlugin("QuickShop-Hikari");
      if(plugin != null) {
        return plugin;
      }
      // Also try "QuickShop" as plugin name
      final Plugin plugin2 = Bukkit.getPluginManager().getPlugin("QuickShop");
      if(plugin2 != null) {
        return plugin2;
      }
    } catch(final Exception e) {
      // Plugin manager approach failed, continue to next approach
    }
    
    // Approach 2: Try to get from service provider
    try {
      final RegisteredServiceProvider<QuickShopProvider> provider = Bukkit.getServicesManager().getRegistration(QuickShopProvider.class);
      if(provider != null) {
        return provider.getPlugin();
      }
    } catch(final Exception e) {
      // Service provider failed, continue to next approach
    }
    
    // Approach 3: Try to get from QuickShop instance via reflection
    try {
      final Class<?> quickShopClass = Class.forName("com.ghostchu.quickshop.QuickShop");
      Object quickShopInstance = null;
      
      // First try to get the static instance field directly
      try {
        final java.lang.reflect.Field instanceField = quickShopClass.getDeclaredField("instance");
        instanceField.setAccessible(true);
        quickShopInstance = instanceField.get(null);
      } catch(final Exception e) {
        // Field access failed, try getInstance() method
        try {
          final java.lang.reflect.Method getInstanceMethod = quickShopClass.getDeclaredMethod("getInstance");
          quickShopInstance = getInstanceMethod.invoke(null);
        } catch(final Exception ex) {
          // Method access failed
        }
      }
      
      if(quickShopInstance != null) {
        // Try to get JavaPlugin instance via getJavaPlugin() method
        try {
          final java.lang.reflect.Method getJavaPluginMethod = quickShopClass.getDeclaredMethod("getJavaPlugin");
          final Object javaPluginInstance = getJavaPluginMethod.invoke(quickShopInstance);
          if(javaPluginInstance != null) {
            return (Plugin) javaPluginInstance;
          }
        } catch(final Exception e) {
          // getJavaPlugin() method failed, try to get the javaPlugin field directly
          try {
            final java.lang.reflect.Field javaPluginField = quickShopClass.getDeclaredField("javaPlugin");
            javaPluginField.setAccessible(true);
            final Object javaPluginInstance = javaPluginField.get(quickShopInstance);
            if(javaPluginInstance != null) {
              return (Plugin) javaPluginInstance;
            }
          } catch(final Exception ex) {
            // Field access failed
          }
        }
      }
    } catch(final Exception e) {
      // Reflection approach failed
    }
    
    // If we reach here, no plugin instance available
    throw new IllegalStateException("QuickShop hadn't loaded at this moment.");
  }

  /**
   * Retrieves the map of all registered hooks in the QuickShop system. Each hook
   * is identified by its unique string identifier and provides custom integration
   * capabilities for plugins or addons.
   *
   * @return a map containing hook identifiers as keys and their corresponding Hook
   *         instances as values. The map will be empty if no hooks are registered.
   */
  Map<String, Hook> hooks();

  /**
   * Iterates through all registered hooks in the QuickShop system and enables them
   * if they meet the requirements for activation. The hooks are retrieved from the
   * internal map of registered hooks, where each hook is identified by a unique string key.
   *
   * This method ensures that hooks capable of being enabled are activated, allowing
   * for custom integrations or behaviors added by plugins or addons to become functional.
   *
   * The activation of individual hooks depends on their internal logic, as determined
   * by the {@code canEnable()} method of each hook. If a hook is eligible, its {@code enable()}
   * method is invoked to update its state.
   *
   * Note: This method operates on all hooks currently available in the system through
   * the {@code hooks()} method and does not handle any hooks added or removed after its invocation.
   */
  default void loadHooks() {

    for(final Hook hook : hooks().values()) {

      if(hook.canEnable()) {
        hook.enable();
      }
    }
  }

  /**
   * Adds a new hook to the QuickShop system. The hook is identified by its unique identifier
   * and is stored in the hooks map. This allows plugins or addons to integrate with
   * QuickShop by providing custom behavior through hooks.
   *
   * @param hook the hook to be added, must not be null. The identifier of the hook must be unique.
   */
  default void addHook(final Hook hook) {

    hooks().put(hook.identifier().toLowerCase(Locale.ROOT), hook);
  }

  /**
   * Removes a hook from the QuickShop system using its unique identifier. The hook is removed
   * from the internal hooks map, which is used to manage integrations or custom behaviors added
   * to QuickShop by plugins or addons.
   *
   * @param identifier the unique identifier of the hook to be removed, must not be null.
   */
  default void removeHook(final String identifier) {

    hooks().remove(identifier.toLowerCase(Locale.ROOT));
  }

  /**
   * Getting command manager that allow addon direct access QuickShop sub-command system
   *
   * @return The command manager
   */
  CommandManager getCommandManager();

  /**
   * Getting the helper to directly access the database
   *
   * @return The database helper
   */
  DatabaseHelper getDatabaseHelper();

  /**
   * Getting this server game version
   *
   * @return Game version
   */
  GameVersion getGameVersion();

  /**
   * Gets registry of InventoryWrappers
   *
   * @return registry
   */
  @NotNull
  InventoryWrapperRegistry getInventoryWrapperRegistry();

  /**
   * Getting current using ItemMatcher impl
   *
   * @return The item matcher
   */
  ItemMatcher getItemMatcher();

  /**
   * Retrieves the EconomyManager instance that manages all economies associated with their unique
   * identifiers.
   *
   * @return The EconomyManager instance.
   */
  EconomyManager getEconomyManager();

  /**
   * Getting the control panel manager
   *
   * @return Shop control panel manager
   */
  ShopControlPanelManager getShopControlPanelManager();

  /**
   * Retrieves the InteractionManager associated with this QuickShopProvider.
   *
   * @return The InteractionManager that manages InteractionBehaviors and InteractionTypes.
   */
  InteractionManager getInteractionManager();

  /**
   * Getting Shop Manager which managing most of shops
   *
   * @return Shop manager
   */
  ShopManager getShopManager();

  /**
   * Getting text manager that allow addon to create a user language locale based message
   *
   * @return The text maanger
   */
  TextManager getTextManager();

  /**
   * Getting QuickShop current stacking item support status
   *
   * @return Stacking Item support enabled
   */
  boolean isAllowStack();

  /**
   * Getting QuickShop current display item support status
   *
   * @return Display item enabled
   */
  boolean isDisplayEnabled();

  RankLimiter getRankLimiter();

  PlayerFinder getPlayerFinder();

  /**
   * Check if fee required for changing shop price
   *
   * @return requires fee
   */
  boolean isPriceChangeRequiresFee();

  /**
   * Logs a event into logs database / file
   *
   * @param eventObject event object, must can be serialized by Gson.
   */
  void logEvent(@NotNull Object eventObject);

  /**
   * Register a localized translation key mapping to another key or fixed string
   *
   * @param translationKey the key to
   * @param key            the key to map to or a fixed string
   */
  void registerLocalizedTranslationKeyMapping(@NotNull String translationKey, @NotNull String key);

  Semver getSemVersion();

  ShopItemBlackList getShopItemBlackList();

  RegistryManager getRegistry();
}
