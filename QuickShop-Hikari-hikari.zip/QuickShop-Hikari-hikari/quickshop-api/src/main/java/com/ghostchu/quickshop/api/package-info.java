/**
 * The QuickShop API package
 */
package com.ghostchu.quickshop.api;