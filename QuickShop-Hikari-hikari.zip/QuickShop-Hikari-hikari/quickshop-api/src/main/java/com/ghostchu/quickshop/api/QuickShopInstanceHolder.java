package com.ghostchu.quickshop.api;

import org.bukkit.plugin.Plugin;

public class QuickShopInstanceHolder {

  protected final Plugin plugin;

  public QuickShopInstanceHolder(final Plugin plugin) {

    this.plugin = plugin;
  }
}
