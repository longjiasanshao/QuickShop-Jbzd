package com.ghostchu.quickshop.api.database.bean;

public interface InfoRecord {

  long getShopId();

  String getWorld();

  int getX();

  int getY();

  int getZ();
}
