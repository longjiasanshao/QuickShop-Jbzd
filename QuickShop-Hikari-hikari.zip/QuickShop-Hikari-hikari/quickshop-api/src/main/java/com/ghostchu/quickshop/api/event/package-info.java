/**
 * The QuickShop events that allow addons to listen to.
 */
package com.ghostchu.quickshop.api.event;