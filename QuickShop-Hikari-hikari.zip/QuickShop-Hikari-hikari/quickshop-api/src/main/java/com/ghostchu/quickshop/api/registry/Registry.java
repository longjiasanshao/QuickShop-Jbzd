package com.ghostchu.quickshop.api.registry;

public interface Registry {
}
