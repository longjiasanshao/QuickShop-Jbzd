package com.ghostchu.quickshop.platform.neoforge;

import com.ghostchu.quickshop.platform.Platform;
import com.vdurmont.semver4j.Semver;
import de.tr7zw.nbtapi.NBTItem;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.loading.FMLLoader;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Sign;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class NeoForgePlatform implements Platform {

    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final Logger logger = LoggerFactory.getLogger(NeoForgePlatform.class);

    @Override
    public void shutdown() {
        // NeoForge shutdown logic
    }

    @NotNull
    @Override
    public Component getDisplayName(@NotNull ItemStack stack) {
        return Bukkit.getServer().getItemFactory().getItemDisplayName(stack);
    }

    @Nullable
    @Override
    public Component getDisplayName(@NotNull ItemMeta meta) {
        return meta.hasDisplayName() ? meta.displayName() : null;
    }

    @NotNull
    @Override
    public Component setItemStackHoverEvent(@NotNull Component oldComponent, @NotNull ItemStack stack) {
        // NeoForge implementation
        return oldComponent;
    }

    @NotNull
    @Override
    public Component getLine(@NotNull Sign sign, int line) {
        return sign.line(line);
    }

    @Nullable
    @Override
    public List<Component> getLore(@NotNull ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        return meta != null ? meta.lore() : null;
    }

    @Nullable
    @Override
    public List<Component> getLore(@NotNull ItemMeta meta) {
        return meta.lore();
    }

    @NotNull
    @Override
    public Component getTranslation(@NotNull Material material) {
        return Component.translatable(material.translationKey());
    }

    @NotNull
    @Override
    public Component getTranslation(@NotNull EntityType entity) {
        return Component.translatable(entity.translationKey());
    }

    @NotNull
    @Override
    public Component getTranslation(@NotNull PotionEffectType potionEffectType) {
        return Component.translatable(potionEffectType.translationKey());
    }

    @NotNull
    @Override
    public Component getTranslation(@NotNull Enchantment enchantment) {
        return Component.translatable(enchantment.translationKey());
    }

    @NotNull
    @Override
    public Component getTranslation(@NotNull ItemStack itemStack) {
        return Component.translatable(itemStack.getType().translationKey());
    }

    @NotNull
    @Override
    public String getTranslationKey(@NotNull Material material) {
        return material.translationKey();
    }

    @NotNull
    @Override
    public String getTranslationKey(@NotNull EntityType entity) {
        return entity.translationKey();
    }

    @NotNull
    @Override
    public String getTranslationKey(@NotNull PotionEffectType potionEffectType) {
        return potionEffectType.translationKey();
    }

    @NotNull
    @Override
    public String getTranslationKey(@NotNull Enchantment enchantment) {
        return enchantment.translationKey();
    }

    @NotNull
    @Override
    public String getTranslationKey(@NotNull ItemStack stack) {
        return stack.getType().translationKey();
    }

    @NotNull
    @Override
    public MiniMessage miniMessage() {
        return miniMessage;
    }

    @Override
    public void registerCommand(@NotNull String prefix, @NotNull Command command) {
        // NeoForge implementation
    }

    @Override
    public void sendMessage(@NotNull CommandSender sender, @NotNull Component component) {
        sender.sendMessage(component);
    }

    @Override
    public void sendSignTextChange(@NotNull Player player, @NotNull Sign sign, boolean glowing, @NotNull List<Component> components) {
        // NeoForge implementation
    }

    @Override
    public void setDisplayName(@NotNull ItemStack stack, @Nullable Component component) {
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(component);
            stack.setItemMeta(meta);
        }
    }

    @Override
    public void setDisplayName(@NotNull Entity entity, @Nullable Component component) {
        entity.customName(component);
    }

    @Override
    public void setLines(@NotNull Sign sign, @NotNull List<Component> component) {
        for (int i = 0; i < Math.min(component.size(), 4); i++) {
            sign.line(i, component.get(i));
        }
    }

    @Override
    public void setLore(@NotNull ItemStack stack, @NotNull Collection<Component> components) {
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.lore(List.copyOf(components));
            stack.setItemMeta(meta);
        }
    }

    @Override
    public void updateTranslationMappingSection(@NotNull Map<String, String> mapping) {
        // NeoForge implementation
    }

    @NotNull
    @Override
    public Logger getSlf4jLogger(@NotNull Plugin parent) {
        return logger;
    }

    @NotNull
    @Override
    public String getMinecraftVersion() {
        // Get NeoForge Minecraft version
        return "1.21.1";
    }
}
